import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import Anthropic from "@anthropic-ai/sdk";

const router: IRouter = Router();

const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

function getAnthropicClient(): Anthropic {
  const apiKey = process.env["ANTHROPIC_API_KEY"];
  if (!apiKey) {
    throw new Error("ANTHROPIC_API_KEY environment variable is not set");
  }
  return new Anthropic({ apiKey });
}

const NUTRITION_PROMPT = `You are a professional nutritionist and food recognition expert. Analyze this food image and provide a detailed nutritional breakdown.

Please respond with ONLY valid JSON in the following exact format (no markdown, no extra text):
{
  "detected_foods": ["food item 1", "food item 2"],
  "serving_description": "description of the portion/serving visible",
  "confidence": "high|medium|low",
  "calories": { "amount": 350, "unit": "kcal" },
  "macronutrients": {
    "protein": { "amount": 25, "unit": "g" },
    "carbohydrates": { "amount": 40, "unit": "g" },
    "fat": { "amount": 12, "unit": "g" },
    "fiber": { "amount": 5, "unit": "g" },
    "sugar": { "amount": 8, "unit": "g" }
  },
  "micronutrients": [
    { "name": "Vitamin C", "amount": 15, "unit": "mg", "daily_value_percent": 17 },
    { "name": "Iron", "amount": 2.5, "unit": "mg", "daily_value_percent": 14 },
    { "name": "Calcium", "amount": 120, "unit": "mg", "daily_value_percent": 9 }
  ],
  "health_notes": "Brief health assessment and notable nutritional highlights in 2-3 sentences.",
  "disclaimer": "Nutritional values are estimates based on visual analysis and may vary."
}

Provide realistic estimates based on what you can see. Include at least 4-6 micronutrients that are notably present. If multiple foods are visible, provide combined totals.`;

router.post(
  "/analyze",
  upload.single("image"),
  async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        res.status(400).json({ error: "No image file provided" });
        return;
      }

      const imageBase64 = req.file.buffer.toString("base64");
      const mediaType = req.file.mimetype as
        | "image/jpeg"
        | "image/png"
        | "image/gif"
        | "image/webp";

      const anthropic = getAnthropicClient();

      const message = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 8192,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "image",
                source: {
                  type: "base64",
                  media_type: mediaType,
                  data: imageBase64,
                },
              },
              {
                type: "text",
                text: NUTRITION_PROMPT,
              },
            ],
          },
        ],
      });

      const textContent = message.content.find((c) => c.type === "text");
      if (!textContent || textContent.type !== "text") {
        res.status(500).json({ error: "No text response from AI" });
        return;
      }

      let nutritionData;
      try {
        const rawText = textContent.text.trim();
        const jsonMatch = rawText.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
          throw new Error("No JSON found in response");
        }
        nutritionData = JSON.parse(jsonMatch[0]);
      } catch {
        res
          .status(500)
          .json({ error: "Failed to parse nutrition data from AI response" });
        return;
      }

      res.json({ success: true, data: nutritionData });
    } catch (err) {
      const error = err as Error;
      if (error.message.includes("ANTHROPIC_API_KEY")) {
        res.status(500).json({ error: "API key not configured" });
      } else {
        res.status(500).json({ error: error.message || "Analysis failed" });
      }
    }
  },
);

export default router;
