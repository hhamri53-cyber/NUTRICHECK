import { useState, useRef, useCallback } from "react";
import "./nutricheck.css";

interface MacroNutrient {
  amount: number;
  unit: string;
}

interface Macronutrients {
  protein: MacroNutrient;
  carbohydrates: MacroNutrient;
  fat: MacroNutrient;
  fiber: MacroNutrient;
  sugar: MacroNutrient;
}

interface Micronutrient {
  name: string;
  amount: number;
  unit: string;
  daily_value_percent?: number;
}

interface NutritionData {
  detected_foods: string[];
  serving_description: string;
  confidence: "high" | "medium" | "low";
  calories: { amount: number; unit: string };
  macronutrients: Macronutrients;
  micronutrients: Micronutrient[];
  health_notes: string;
  disclaimer: string;
}

const MACRO_CONFIG = [
  { key: "protein" as const, label: "Protein", max: 100, colorClass: "protein" },
  { key: "carbohydrates" as const, label: "Carbs", max: 150, colorClass: "carbs" },
  { key: "fat" as const, label: "Fat", max: 80, colorClass: "fat" },
  { key: "fiber" as const, label: "Fiber", max: 40, colorClass: "fiber" },
  { key: "sugar" as const, label: "Sugar", max: 80, colorClass: "sugar" },
];

function MacroBar({
  label,
  amount,
  unit,
  pct,
  colorClass,
}: {
  label: string;
  amount: number;
  unit: string;
  pct: number;
  colorClass: string;
}) {
  return (
    <div className="macro-bar-row">
      <div className="macro-label">
        <span>{label}</span>
        <span className="macro-value">
          {amount}
          {unit}
        </span>
      </div>
      <div className="bar-track">
        <div
          className={`bar-fill ${colorClass}`}
          style={{ width: `${Math.min(pct, 100)}%` }}
        />
      </div>
    </div>
  );
}

function MicroCard({ item }: { item: Micronutrient }) {
  const dvPct = Math.min(item.daily_value_percent ?? 0, 100);
  return (
    <div className="micro-item">
      <div className="micro-name">{item.name}</div>
      <div className="micro-values">
        <span className="micro-amount">
          {item.amount}
          {item.unit}
        </span>
        {dvPct > 0 && <span className="micro-dv">{dvPct}% DV</span>}
      </div>
      {dvPct > 0 && (
        <div className="micro-bar-track">
          <div className="micro-bar-fill" style={{ width: `${dvPct}%` }} />
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<NutritionData | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    if (!f.type.startsWith("image/")) return;
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setError(null);
    setData(null);
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  const removeFile = () => {
    setFile(null);
    setPreviewUrl(null);
    setData(null);
    setError(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append("image", file);

    try {
      const res = await fetch(`${import.meta.env.BASE_URL}api/analyze`, {
        method: "POST",
        body: formData,
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        setError(json.error || "Analysis failed. Please try again.");
        return;
      }
      setData(json.data);
    } catch {
      setError("Network error. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <header className="header">
        <div className="logo">🥗</div>
        <div className="brand">
          <h1>NutriCheck</h1>
          <p>AI-Powered Food Nutrition Analyzer</p>
        </div>
      </header>

      <main className="main">
        {/* Upload Panel */}
        <div className="panel upload-panel">
          <div className="panel-header">
            <h2>Upload Food Photo</h2>
            <p>Supports JPG, PNG, WebP — up to 10MB</p>
          </div>
          <div className="panel-body">
            {!previewUrl ? (
              <div
                className={`drop-zone${dragOver ? " dragover" : ""}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => inputRef.current?.click()}
              >
                <input
                  ref={inputRef}
                  type="file"
                  accept="image/*"
                  style={{ display: "none" }}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleFile(f);
                  }}
                />
                <span className="drop-icon">📸</span>
                <h3>Drop your food photo here</h3>
                <p>or click to browse</p>
                <span className="browse-btn">Choose Photo</span>
              </div>
            ) : (
              <div className="preview-wrap">
                <img src={previewUrl} alt="Food preview" className="preview-img" />
                <div className="preview-overlay" />
                <button className="btn-remove" onClick={removeFile}>
                  ✕ Remove
                </button>
              </div>
            )}

            <button
              className="analyze-btn"
              disabled={!file || loading}
              onClick={analyze}
            >
              {loading ? (
                <>
                  <span className="spinner" />
                  Analyzing...
                </>
              ) : (
                "🔍 Analyze Nutrition"
              )}
            </button>
          </div>
        </div>

        {/* Results Panel */}
        <div className="panel results-panel">
          {!data && !error && (
            <div className="empty-state">
              <span className="empty-icon">🍽️</span>
              <h3>No analysis yet</h3>
              <p>Upload a photo and click Analyze to get detailed nutritional information</p>
            </div>
          )}

          {error && (
            <div className="error-box">⚠️ {error}</div>
          )}

          {data && (
            <div className="results-content">
              {/* Detected Foods */}
              <div className="section foods-section">
                <div className="section-label">Detected Foods</div>
                <div className="foods-list">
                  {data.detected_foods.map((f) => (
                    <span key={f} className="food-tag">
                      {f}
                    </span>
                  ))}
                  <span className={`confidence-badge ${data.confidence}`}>
                    ● {data.confidence} confidence
                  </span>
                </div>
              </div>

              {/* Calories */}
              <div className="section calories-hero">
                <div>
                  <div className="section-label">Total Calories</div>
                  <div className="calories-big">
                    <span className="cal-number">{data.calories.amount}</span>
                    <span className="cal-unit">kcal</span>
                  </div>
                </div>
                <div className="serving-info">{data.serving_description}</div>
              </div>

              {/* Macros */}
              <div className="section macros-section">
                <div className="section-label">Macronutrients</div>
                <div className="macro-bars">
                  {MACRO_CONFIG.map(({ key, label, max, colorClass }) => {
                    const item = data.macronutrients[key];
                    if (!item) return null;
                    return (
                      <MacroBar
                        key={key}
                        label={label}
                        amount={item.amount}
                        unit={item.unit}
                        pct={(item.amount / max) * 100}
                        colorClass={colorClass}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Micronutrients */}
              <div className="section micro-section">
                <div className="section-label">Micronutrients</div>
                <div className="micro-grid">
                  {data.micronutrients.map((m) => (
                    <MicroCard key={m.name} item={m} />
                  ))}
                </div>
              </div>

              {/* Health Notes */}
              <div className="section notes-section">
                <div className="section-label">Health Assessment</div>
                <div className="health-note">{data.health_notes}</div>
                <p className="disclaimer">{data.disclaimer}</p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
